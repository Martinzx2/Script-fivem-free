# Disable-NPC-better-than-script-Fivem-

//Thai language//
ปิด NPC ไม่หน่วง ไม่ต้องเพิ่ม Script แค่ใส่ code ไว้ใน server. cfg 

//English language//
Disable NPC with only one code in server.cfg

![image](https://user-images.githubusercontent.com/76675565/196014025-851d82cc-be04-4aca-9124-b37292c26758.png)
